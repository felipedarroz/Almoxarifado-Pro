
import React, { useState } from 'react';
import { Package, Lock, User as UserIcon, Key, ArrowRight, UserPlus } from 'lucide-react';
import { User } from '../types';

interface LoginProps {
  onLogin: (user: User) => void;
  users: User[];
  onRegister: (newUser: Partial<User>) => void;
}

export const Login: React.FC<LoginProps> = ({ onLogin, users, onRegister }) => {
  const [isRegistering, setIsRegistering] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (isRegistering) {
        if (password !== confirmPassword) {
            setError('As senhas não conferem.');
            return;
        }
        if (username.length < 3) {
            setError('Usuário muito curto.');
            return;
        }
        onRegister({ username, password });
    } else {
        const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());
        
        if (user) {
            if (user.password === password) {
                onLogin(user);
            } else {
                setError('Senha incorreta.');
            }
        } else {
          setError('Usuário não encontrado.');
        }
    }
  };

  const toggleMode = () => {
    setIsRegistering(!isRegistering);
    setError('');
    setUsername('');
    setPassword('');
    setConfirmPassword('');
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-slate-900 relative overflow-hidden">
      {/* Background Decorativo */}
      <div className="absolute inset-0 z-0">
         <div className="absolute top-0 -left-4 w-96 h-96 bg-blue-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob"></div>
         <div className="absolute top-0 -right-4 w-96 h-96 bg-purple-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-2000"></div>
         <div className="absolute -bottom-8 left-20 w-96 h-96 bg-indigo-500 rounded-full mix-blend-multiply filter blur-3xl opacity-20 animate-blob animation-delay-4000"></div>
         <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20"></div>
      </div>

      <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl w-full max-w-4xl overflow-hidden flex flex-col md:flex-row z-10 min-h-[500px]">
        
        {/* Lado Esquerdo (Info) */}
        <div className="bg-gradient-to-br from-blue-600 to-indigo-800 p-8 md:w-5/12 text-white flex flex-col justify-between relative overflow-hidden">
           <div className="relative z-10">
             <div className="bg-white/20 w-12 h-12 rounded-xl flex items-center justify-center mb-6 backdrop-blur-md">
                <Package className="text-white w-7 h-7" />
             </div>
             <h1 className="text-3xl font-bold mb-2">Almoxarifado Pro</h1>
             <p className="text-blue-100 text-sm leading-relaxed">
               Sistema integrado de gestão de entregas, pendências e controle comercial.
             </p>
           </div>
           
           <div className="relative z-10 mt-8 md:mt-0">
             <p className="text-xs font-medium text-blue-200 uppercase tracking-wider mb-2">Módulos</p>
             <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm text-blue-50/80"><div className="w-1.5 h-1.5 rounded-full bg-blue-300"></div> Gestão de Notas</div>
                <div className="flex items-center gap-2 text-sm text-blue-50/80"><div className="w-1.5 h-1.5 rounded-full bg-orange-300"></div> Pendências de Técnicos</div>
                <div className="flex items-center gap-2 text-sm text-blue-50/80"><div className="w-1.5 h-1.5 rounded-full bg-purple-300"></div> Planejamento Comercial</div>
             </div>
           </div>

           {/* Círculos decorativos internos */}
           <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-white/10 rounded-full blur-2xl"></div>
        </div>

        {/* Lado Direito (Form) */}
        <div className="p-8 md:w-7/12 flex flex-col justify-center bg-white relative">
          <div className="max-w-md mx-auto w-full">
            <h2 className="text-2xl font-bold text-slate-800 mb-1">
                {isRegistering ? 'Criar Conta' : 'Bem-vindo de volta'}
            </h2>
            <p className="text-sm text-slate-500 mb-6">
                {isRegistering ? 'Preencha os dados para começar.' : 'Insira suas credenciais para acessar.'}
            </p>

            <form onSubmit={handleSubmit} className="space-y-4">
              {error && (
                <div className="bg-red-50 text-red-600 text-sm p-3 rounded-lg border border-red-100 flex items-center gap-2 animate-in slide-in-from-top-2">
                  <AlertCircle size={16} /> {error}
                </div>
              )}
              
              <div className="space-y-4">
                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-1 ml-1">Usuário</label>
                    <div className="relative group">
                        <UserIcon className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors w-5 h-5" />
                        <input
                        type="text"
                        required
                        className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-slate-50 focus:bg-white text-slate-900 outline-none"
                        placeholder="Nome de usuário"
                        value={username}
                        onChange={(e) => setUsername(e.target.value)}
                        />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-600 uppercase mb-1 ml-1">Senha</label>
                    <div className="relative group">
                        <Key className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors w-5 h-5" />
                        <input
                        type="password"
                        required
                        className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-slate-50 focus:bg-white text-slate-900 outline-none"
                        placeholder="••••••••"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                        />
                    </div>
                  </div>

                  {isRegistering && (
                      <div className="animate-in fade-in slide-in-from-top-2 duration-300">
                        <label className="block text-xs font-bold text-slate-600 uppercase mb-1 ml-1">Confirmar Senha</label>
                        <div className="relative group">
                            <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 group-focus-within:text-blue-500 transition-colors w-5 h-5" />
                            <input
                            type="password"
                            required
                            className="w-full pl-10 pr-4 py-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all bg-slate-50 focus:bg-white text-slate-900 outline-none"
                            placeholder="••••••••"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            />
                        </div>
                      </div>
                  )}
              </div>

              <button
                type="submit"
                className="w-full flex items-center justify-center gap-2 bg-slate-900 hover:bg-slate-800 text-white py-3.5 rounded-xl font-bold transition-all shadow-lg hover:shadow-xl transform hover:-translate-y-0.5 mt-2"
              >
                {isRegistering ? (
                    <>
                        Criar Conta <UserPlus size={18} />
                    </>
                ) : (
                    <>
                        Acessar Sistema <ArrowRight size={18} />
                    </>
                )}
              </button>
            </form>

            <div className="mt-6 text-center">
                <p className="text-sm text-slate-500">
                    {isRegistering ? 'Já tem uma conta?' : 'Não tem acesso?'}
                    <button 
                        onClick={toggleMode}
                        className="ml-1 font-bold text-blue-600 hover:text-blue-800 transition-colors hover:underline"
                    >
                        {isRegistering ? 'Fazer Login' : 'Criar Conta'}
                    </button>
                </p>
            </div>

            {!isRegistering && (
                <div className="mt-8 pt-6 border-t border-slate-100">
                    <p className="text-[10px] text-center text-slate-400 font-medium mb-2 uppercase tracking-wide">Acesso Rápido (Demo)</p>
                    <div className="flex flex-wrap justify-center gap-2 text-[10px] text-slate-500">
                        <span className="bg-slate-100 px-2 py-1 rounded border border-slate-200">admin / 1234</span>
                        <span className="bg-slate-100 px-2 py-1 rounded border border-slate-200">editor / 1234</span>
                    </div>
                </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Footer Info */}
      <div className="absolute bottom-4 text-center w-full z-10 text-slate-500 text-xs opacity-60">
        &copy; {new Date().getFullYear()} Almoxarifado Pro. Todos os direitos reservados.
      </div>

      {/* Helper icon for errors */}
      {/* Keep existing AlertCircle import */}
    </div>
  );
};

// Import necessário para o componente funcionar sem erros no bloco acima
import { AlertCircle } from 'lucide-react';
